import createElement from "./createElement"
import render from "./render"
import Component from "./Component"

export default {
  createElement,
  render,
  Component
}
